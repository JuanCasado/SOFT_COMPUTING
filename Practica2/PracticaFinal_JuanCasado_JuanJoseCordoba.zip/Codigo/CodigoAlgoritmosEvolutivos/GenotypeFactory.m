function genotypeFactory = GenotypeFactory (domain)
    genotypeFactory = @() genotypeWithDomain(domain);
end